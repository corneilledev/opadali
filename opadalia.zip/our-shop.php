

          <?php

// // Inclure le fichier autoload.php de Composer
// require_once '../../Wowy v1.18/ecommerce/vendor/autoload.php';

// // Initialiser l'application Laravel
// $app = require_once '../../Wowy v1.18/ecommerce/bootstrap/app.php';
// $kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);
// $response = $kernel->handle(
//     $request = Illuminate\Http\Request::capture()
// );

// // Afficher la vue Laravel
// echo $app->make('view')->make('welcome')->render();

// $kernel->terminate($request, $response); 

// $link = 'http://events.ÔPADALIA.fr/ecommerce/'; // URL du lien à afficher
// $content = file_get_contents($link); // Récupération du contenu du lien
// echo $content; // Affichage du contenu du lien
header('localhost');
?>




            <?php include('includes/footer.php'); ?>