<form action="" method="post">
<label for="quantity">Quantité (minimum 10) :</label>
            <input type="number"  name="quantity" min="100">
            <input type="submit">
</form>